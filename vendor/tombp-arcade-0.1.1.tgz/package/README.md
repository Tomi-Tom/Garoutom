# `@tombp/arcade`

Le cadre commun des onze jeux de la collection, et du hub qui les range.

**Le contrat tient en une phrase : le cadre est commun, l'intérieur est
libre.** Même gabarit d'accueil, même lien de retour, même bouton de son, même
transition, même écran de fin, même signature — et chaque jeu garde sa matière,
sa palette et son vocabulaire. Aucun composant d'ici n'écrit une couleur en
dur : tous passent par quatre variables CSS que le jeu redéfinit.

## Installer

```bash
npm i @tombp/arcade
```

Puis, une fois, dans le point d'entrée du client :

```ts
import '@tombp/arcade/arcade.css'
```

Et les quatre variables, sur le `:root` du jeu — c'est tout ce que le paquet
demande, et c'est ce qui fait qu'il porte la couleur du jeu et pas celle du hub :

```css
:root {
  --arcade-encre: var(--ink-mid);
  --arcade-fond: color-mix(in srgb, var(--paper) 80%, transparent);
  --arcade-trait: var(--rule-firm);
  --arcade-accent: var(--crayon);
}
```

Une cinquième, facultative, règle la couleur du texte posé **sur** l'accent
(le bouton REJOUER) : `--arcade-fond-sur-accent`, noir par défaut.

Pour les tests de rendu, `vitest.config.ts` du client :

```ts
import { defineConfig } from 'vitest/config'
import { configVitestRendu } from '@tombp/arcade/test'

export default defineConfig(configVitestRendu())
```

Cette configuration pose jsdom, `globals`, et une mise en scène commune
(doublures de `matchMedia` et d'`AudioContext`, nettoyage entre deux tests).
Elle suppose ces paquets dans les `devDependencies` du jeu :

```bash
npm i -D vitest jsdom @testing-library/react @testing-library/jest-dom @testing-library/user-event
```

Les peers `react` et `react-dom` (18 ou plus) sont à la charge du jeu.

### En attendant la publication

Le paquet n'est pas encore sur npm : `npm i @tombp/arcade` échouera tant que
Tom n'aura pas créé le compte et lancé l'étape 3 de la tâche B12. D'ici là, les
dix autres jeux le consomment depuis une archive `npm pack` vendue dans leur
propre dépôt — `vendor/tombp-arcade-0.1.0.tgz`, déclarée en `file:` :

```json
"@tombp/arcade": "file:vendor/tombp-arcade-0.1.0.tgz"
```

C'est le seul chemin qui traverse le build Vercel d'un dépôt privé sans jeton :
l'archive voyage avec le jeu. Le jour de la publication, la ligne redevient un
numéro de version, et l'archive disparaît de chaque dépôt. Le hub, lui, n'est
pas concerné : il consomme le paquet par son espace de travail npm.

## Ce que le paquet porte

| Export | Rôle |
|---|---|
| `FICHES`, `fiche(id)` | Le catalogue des onze fiches — titre, sous-titre, pitch, palette. **Le pitch vient d'ici et de nulle part ailleurs.** |
| `<LienArcade id />` | Le lien de retour au hub, qui rouvre le rack **sur la cartouche du jeu** (`arcade.tombp.fr/#TBP-006`). |
| `<BoutonSon />` | Le bouton de son, autonome : il pose lui-même l'amorce audio sur le premier geste. `curseur` ajoute la réglette. |
| `useVolume()` | Le réglage partagé — `{ volume, coupe, regler, basculer }` — sous une seule clé, `tombp.volume`. Zéro veut dire coupé. |
| `bruitages` | Quatre sons synthétisés : `clic()`, `claque()`, `cloche()`, `verdict('gagne' \| 'perdu' \| 'neutre')`. Zéro fichier. |
| `deverrouiller()`, `contexte()`, `bus()` | Le contexte audio partagé, et le bus sur lequel un jeu branche ses propres sons pour suivre le même volume. |
| `abonnerVolume(f)`, `appliquerVolume()` | Suivre le réglage hors de React. Le bus le fait déjà tout seul : un jeu n'en a besoin que pour ses propres gains. |
| `<Rideau sens />` | La transition en deux moitiés : `ouverture` à l'arrivée, `fermeture` au départ. 320 ms, la même courbe que l'insertion du hub. |
| `<DosDeBoite id />` | L'écran d'accueil type, rempli par le catalogue. Ses `children` sont les commandes du jeu. |
| `<EcranFin … />` | L'écran de fin type : verdict, chiffre, trois lignes, un contenu libre, puis REJOUER · ARCADE · PARTAGER. |
| `configVitestRendu()` | Le socle de test de rendu, en trois lignes (`@tombp/arcade/test`). |

## L'accueil

```tsx
import { DosDeBoite, Rideau, bruitages } from '@tombp/arcade'

export function Accueil({ surCreer }: { surCreer: () => void }) {
  return (
    <>
      <Rideau sens="ouverture" />
      <DosDeBoite id="TBP-006">
        <button
          type="button"
          onClick={() => {
            bruitages.claque()
            surCreer()
          }}
        >
          CRÉER UNE TABLE
        </button>
      </DosDeBoite>
    </>
  )
}
```

Le dos de boîte affiche le numéro de série, le statut, le titre, le sous-titre,
le pitch, genre / joueurs / année, et signe en bas. Il met aussi le numéro dans
le titre de l'onglet. Le lien de retour est en haut à gauche, le son en haut à
droite : le composant les pose lui-même.

## La fin de partie

```tsx
import { EcranFin } from '@tombp/arcade'

export function Fin({ score, rejouer }: { score: number; rejouer: () => void }) {
  return (
    <EcranFin
      id="TBP-006"
      verdict="GAGNÉ"
      chiffre={String(score)}
      lignes={['14 tours', '3 yams', 'meilleure série : 5']}
      surRejouer={rejouer}
      actions={[{ libelle: 'REVANCHE', surClic: () => {} }]}
    >
      {/* Ce que le jeu veut montrer sous ses trois lignes : un classement,
          un podium, une frise des ratés. Le gabarit tient le haut et le bas. */}
      <ol>
        <li>Tom — 312</li>
        <li>Léa — 280</li>
      </ol>
    </EcranFin>
  )
}
```

Les trois actions gardent **toujours le même ordre** : REJOUER · ARCADE ·
PARTAGER. C'est le seul point où le paquet impose quelque chose au jeu.
`surRejouer` absent = le bouton REJOUER disparaît. Les `actions` du jeu viennent
après les trois. La couleur du son de fin se déduit du verdict (`GAGN…`,
`PERDU`…) ; `couleur` la force.

## Le départ

Le lien de retour est un vrai lien. Pour jouer le rideau avant de partir :

```tsx
const [depart, setDepart] = useState(false)

<LienArcade id="TBP-006" surDepart={() => setDepart(true)} />
{depart && <Rideau sens="fermeture" />}
```

Le navigateur suit le lien pendant que le rideau se ferme, et le rideau reste
en place : le démonter rallumerait le jeu pendant le chargement du hub.

## Les bruitages du jeu

Le jeu ouvre ses propres sons **sur le même contexte** — un onglet n'a droit
qu'à un petit nombre d'`AudioContext` :

```ts
import { contexte, bus, deverrouiller } from '@tombp/arcade'

function monSon() {
  const ctx = deverrouiller() // dans le gestionnaire d'un vrai geste, sans await avant
  const sortie = bus()
  if (!ctx || !sortie) return
  const osc = ctx.createOscillator()
  osc.connect(sortie) // suit le volume de l'utilisateur
  osc.start()
  osc.stop(ctx.currentTime + 0.1)
}
```

Le bus suit le réglage **de lui-même**, y compris quand il change en cours de
route : rien à rappeler après un `basculer()` ou un `regler()`. Un jeu qui
tient un gain à lui, en dehors du bus, s'abonne pour le suivre :

```ts
import { abonnerVolume, lireVolume } from '@tombp/arcade'

const desabonner = abonnerVolume((v) => {
  monGain.gain.setTargetAtTime(v, ctx.currentTime, 0.02)
})
```

## Où vit le réglage de son

Dans un **cookie de `.tombp.fr`**, et non dans `localStorage`.

`localStorage` est cloisonné par origine, et la collection en compte douze : le
hub et onze sous-domaines. Une seule clé n'y fait pas un seul réglage —
Rythmotom l'a mesuré en production, en écrivant `0.123` chez lui et en relisant
`null` au hub. Couper le son au hub ne coupait rien dans les jeux.

Le cookie (`path=/`, `SameSite=Lax`, un an, `Secure` en HTTPS) est la source de
vérité et traverse les douze origines. `localStorage` est écrit en même temps et
sert de repli : hors `tombp.fr` — en `localhost`, en préproduction Vercel — et
dans un navigateur qui refuse les cookies. À la lecture, le cookie l'emporte.

Rien à faire dans un jeu : `useVolume()`, `lireVolume()` et `ecrireVolume()` s'en
occupent.

## La règle du placement

- **Le lien de retour en haut à gauche**, sur l'accueil, la pause et la fin de
  partie. Jamais pendant l'action : une sortie sur le trajet du pouce est un
  piège.
- **Le bouton de son en haut à droite**, jamais en bas.
- Rien de tout cela ne fait moins de 44 px de haut, et rien ne se coupe à
  320 px : les classes du paquet le garantissent, le jeu n'a pas à y penser.

## Ce que l'archive emporte

`dist`, et **les sources qu'il désigne** (pas les tests).

Les fichiers de `dist` portent tous un `sourceMappingURL`, et les cartes visent
`../src/*.tsx`. En ne livrant que `dist`, chaque carte désignait un fichier
absent : `vitest`, chez un jeu, s'ouvrait sur un avertissement par module, et le
saut vers la définition tombait sur un `.d.ts`. Les sources voyagent donc avec
leurs cartes. `paquet.test.ts` le tient en appelant vraiment `npm pack`.

## Publier une version

```bash
cd packages/arcade
npm version patch   # ou minor, majeur
npm publish         # `prepare` construit dist/ ; l'accès public est déclaré dans package.json
```

Le paquet ne contient aucun secret : cinq composants d'interface et un
catalogue, déjà publics dans les bundles servis par les onze sous-domaines.

## Ce que le paquet ne fait pas

Il n'impose ni police, ni couleur, ni mise en page au-delà de ses propres
écrans. Il ne connaît pas les règles d'un jeu. Il ne charge aucun fichier —
ni image, ni son, ni fonte.
