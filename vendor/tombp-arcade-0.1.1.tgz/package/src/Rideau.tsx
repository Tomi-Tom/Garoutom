import { useEffect, useRef, useState } from 'react'

/**
 * La transition en deux moitiés d'un même mouvement.
 *
 * Le hub finit sur l'écrasement du tube — l'écran se réduit à une ligne, puis
 * à un point. Le jeu **commence par l'inverse** : le point se rouvre en ligne,
 * puis en plein écran. Même durée, même courbe. Le passage d'un écran à
 * l'autre cesse d'être un chargement pour devenir un geste.
 *
 * La courbe est celle du hub (`--ease-rack`), recopiée ici pour que le paquet
 * ne dépende pas de la feuille de style du hub.
 */

/** 320 ms. La même valeur des deux côtés, sinon les deux moitiés ne se rejoignent pas. */
export const DUREE_RIDEAU = 320

export interface RideauProps {
  /**
   * `ouverture` — on arrive : le point s'étire, puis le rideau disparaît.
   * `fermeture` — on part : l'écran s'écrase, et le rideau **reste**, parce
   * que le démonter rallumerait le jeu pendant que le navigateur charge le hub.
   */
  sens: 'ouverture' | 'fermeture'
  /** Appelé quand le mouvement est fini. C'est là qu'on navigue, jamais avant. */
  surFin?: () => void
}

export function Rideau({ sens, surFin }: RideauProps) {
  const [fini, setFini] = useState(false)

  // `surFin` passe par une référence plutôt que par les dépendances : une
  // fonction recréée à chaque rendu relancerait la minuterie sans fin.
  const surFinRef = useRef(surFin)
  surFinRef.current = surFin

  useEffect(() => {
    setFini(false)
    const id = window.setTimeout(() => {
      setFini(true)
      surFinRef.current?.()
    }, DUREE_RIDEAU)
    return () => window.clearTimeout(id)
  }, [sens])

  if (sens === 'ouverture' && fini) return null

  return (
    <div
      data-testid="arcade-rideau"
      className={`arcade-rideau arcade-rideau--${sens}`}
      aria-hidden="true"
    />
  )
}
