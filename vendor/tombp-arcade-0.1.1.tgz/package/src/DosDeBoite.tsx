import { useEffect, type ReactNode } from 'react'
import { BoutonSon } from './BoutonSon.js'
import { LienArcade } from './LienArcade.js'
import { fiche } from './fiches.js'

/**
 * L'écran d'accueil type : **le dos de la boîte**.
 *
 * Même gabarit que la fiche du hub — bandeau `TBP-0xx` + statut, titre,
 * sous-titre, pitch, puis les commandes du jeu — mais rempli par **la palette
 * du jeu**, pas par celle du hub. On reconnaît le meuble, pas la couleur.
 *
 * Le pitch vient du catalogue et de nulle part ailleurs. C'est la conséquence
 * salutaire du gabarit : le hub cesse de pouvoir mentir sur le jeu, parce
 * qu'il n'y a plus qu'un texte.
 */

const STATUT: Record<string, string> = {
  live: 'JOUABLE',
  wip: 'EN CHANTIER',
  locked: 'AUCUN DISQUE',
}

export interface DosDeBoiteProps {
  id: string
  /** Les commandes du jeu : boutons, réglages, tout ce qui lui appartient. */
  children?: ReactNode
  className?: string
}

export function DosDeBoite({ id, children, className = '' }: DosDeBoiteProps) {
  const f = fiche(id)

  // L'identifiant est le fil : il court de la cartouche à l'onglet.
  useEffect(() => {
    document.title = `${f.title} · ${f.id}`
  }, [f.title, f.id])

  return (
    <section className={`arcade-dos ${className}`.trim()}>
      <header className="arcade-dos-barre">
        <LienArcade id={f.id} />
        <BoutonSon />
      </header>

      <div className="arcade-dos-corps">
        <p className="arcade-dos-meta">
          <span className="arcade-dos-id">{f.id}</span>
          <span className={`arcade-dos-statut arcade-dos-statut--${f.status}`}>
            {STATUT[f.status] ?? f.status}
          </span>
        </p>

        <h1 className="arcade-dos-titre">{f.title}</h1>
        <p className="arcade-dos-sous">{f.subtitle}</p>
        <p className="arcade-dos-pitch">{f.blurb}</p>

        <dl className="arcade-dos-specs">
          <div>
            <dt>GENRE</dt>
            <dd>{f.genre}</dd>
          </div>
          <div>
            <dt>JOUEURS</dt>
            <dd>{f.players}</dd>
          </div>
          <div>
            <dt>ANNÉE</dt>
            <dd>{f.year}</dd>
          </div>
        </dl>

        {children && <div className="arcade-dos-commandes">{children}</div>}
      </div>

      {/* Un crédit, pas une commande : il vit à côté du numéro et n'a pas le
          droit de se lire comme un bouton de plus. */}
      <footer className="arcade-dos-pied">
        <span>{f.id}</span>
        <span>
          fait par{' '}
          <a href="https://www.tombp.fr" target="_blank" rel="noopener noreferrer">
            Tomi-Tom
          </a>
        </span>
      </footer>
    </section>
  )
}
