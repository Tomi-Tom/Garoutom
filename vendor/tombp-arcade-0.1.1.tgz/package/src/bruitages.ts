import { abonnerVolume, lireVolume } from './volume.js'

/**
 * Les quatre bruitages du cadre commun, synthétisés — **zéro fichier, zéro
 * requête**.
 *
 * Quatre et pas plus, parce que quatre suffisent à dire ce que le cadre a à
 * dire : on navigue (`clic`), on valide un geste (`claque`), on gagne quelque
 * chose (`cloche`), la partie se termine (`verdict`). Tout le reste appartient
 * au jeu, qui ouvre son propre atelier sur le même contexte.
 *
 * Le contexte est partagé exprès : un onglet n'a droit qu'à un petit nombre
 * d'`AudioContext`, et en ouvrir un par module est le meilleur moyen de se
 * retrouver muet au sixième jeu de la collection.
 */

let ctx: AudioContext | null = null
let maitre: GainNode | null = null
/** Le bus ne s'abonne au réglage qu'une fois, à l'ouverture du contexte. */
let busAbonne = false

/** Le plafond du bus des bruitages, sous le volume de l'utilisateur. */
const PLAFOND = 0.32

type Constructeur = typeof AudioContext

/**
 * Ouvre le contexte, ou le reprend s'il dort.
 *
 * **À appeler dans le gestionnaire d'un vrai geste, sans rien d'asynchrone
 * avant.** Sur iOS Safari, une continuation `await` entre l'évènement et cet
 * appel perd le jeton du geste et le déblocage échoue en silence : c'est la
 * leçon de `hub/src/components/VolumeBar.tsx`, et elle a été payée.
 */
export function deverrouiller(): AudioContext | null {
  if (typeof window === 'undefined') return null
  if (!ctx) {
    const Ctor: Constructeur | undefined =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: Constructeur }).webkitAudioContext
    if (!Ctor) return null
    ctx = new Ctor()
    maitre = ctx.createGain()
    maitre.connect(ctx.destination)
    if (!busAbonne) {
      busAbonne = true
      abonnerVolume(appliquerVolume)
    }
  }
  if (ctx.state === 'suspended') void ctx.resume()
  appliquerVolume()
  return ctx
}

/**
 * Remet le bus au volume réglé.
 *
 * Appelée toute seule à chaque changement de réglage, parce que le déblocage
 * n'est pas le bon moment pour ça : le bouton de son débloquait puis
 * basculait, dans cet ordre, et le gain gardait l'ancienne valeur jusqu'au son
 * suivant — on coupait le son et l'on entendait encore le bruitage d'après.
 * Yamstom le contournait chez lui ; ça n'était pas à lui de le faire.
 *
 * Elle n'ouvre rien : tant que personne n'a touché l'écran, il n'y a pas de
 * bus, donc rien à régler.
 */
export function appliquerVolume(): void {
  if (!ctx || !maitre) return
  maitre.gain.setTargetAtTime(PLAFOND * lireVolume(), ctx.currentTime, 0.02)
}

/** Le contexte partagé, pour un jeu qui veut y brancher son propre atelier. */
export function contexte(): AudioContext | null {
  return ctx
}

/** Le bus sur lequel un jeu branche ses sons pour suivre le même volume. */
export function bus(): GainNode | null {
  return maitre
}

interface Note {
  freq: number
  /** Fréquence d'arrivée du glissando, si on en veut un. */
  vers?: number
  duree?: number
  type?: OscillatorType
  gain?: number
  retard?: number
}

function note({ freq, vers, duree = 0.09, type = 'square', gain = 0.5, retard = 0 }: Note): void {
  if (!ctx || !maitre) return
  if (lireVolume() <= 0) return

  const t0 = ctx.currentTime + retard

  const osc = ctx.createOscillator()
  osc.type = type
  osc.frequency.setValueAtTime(freq, t0)
  if (vers) osc.frequency.exponentialRampToValueAtTime(vers, t0 + duree)

  const env = ctx.createGain()
  env.gain.setValueAtTime(0.0001, t0)
  env.gain.exponentialRampToValueAtTime(gain, t0 + 0.008)
  env.gain.exponentialRampToValueAtTime(0.0001, t0 + duree)

  // Un passe-bas doux : sans lui, le carré pique les oreilles au casque.
  const lp = ctx.createBiquadFilter()
  lp.type = 'lowpass'
  lp.frequency.value = 4200

  osc.connect(env).connect(lp).connect(maitre)
  osc.start(t0)
  osc.stop(t0 + duree + 0.05)
}

export type Verdict = 'gagne' | 'perdu' | 'neutre'

export const bruitages = {
  /** On se déplace : un bip court et montant. */
  clic: () => note({ freq: 660, vers: 880, duree: 0.06, type: 'square', gain: 0.25 }),

  /** On valide, on pose, on tape : sec, grave, sans queue. */
  claque: () => {
    note({ freq: 180, vers: 90, duree: 0.07, type: 'square', gain: 0.3 })
    note({ freq: 90, vers: 55, duree: 0.11, type: 'sine', gain: 0.34, retard: 0.01 })
  },

  /** On gagne quelque chose : la quinte qui monte, brève. */
  cloche: () => {
    note({ freq: 880, duree: 0.09, type: 'triangle', gain: 0.26 })
    note({ freq: 1319, duree: 0.22, type: 'triangle', gain: 0.24, retard: 0.07 })
  },

  /**
   * La partie se termine. Trois couleurs, parce qu'un écran de fin qui sonne
   * pareil qu'on ait gagné ou perdu ne dit rien du tout.
   */
  verdict: (issue: Verdict = 'neutre') => {
    if (issue === 'gagne') {
      note({ freq: 523, duree: 0.1, type: 'square', gain: 0.28 })
      note({ freq: 784, duree: 0.1, type: 'square', gain: 0.26, retard: 0.09 })
      note({ freq: 1046, duree: 0.34, type: 'triangle', gain: 0.3, retard: 0.18 })
    } else if (issue === 'perdu') {
      note({ freq: 392, duree: 0.13, type: 'sawtooth', gain: 0.22 })
      note({ freq: 294, duree: 0.16, type: 'sawtooth', gain: 0.22, retard: 0.12 })
      note({ freq: 196, vers: 130, duree: 0.42, type: 'sine', gain: 0.26, retard: 0.26 })
    } else {
      note({ freq: 440, duree: 0.12, type: 'triangle', gain: 0.24 })
      note({ freq: 587, duree: 0.3, type: 'triangle', gain: 0.24, retard: 0.11 })
    }
  },
}
