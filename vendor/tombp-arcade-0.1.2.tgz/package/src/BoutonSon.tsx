import { useEffect } from 'react'
import { deverrouiller } from './bruitages.js'
import { useVolume } from './volume.js'

/**
 * Le bouton de son, le même dans les onze jeux et dans le hub.
 *
 * Il est **autonome** : il pose lui-même l'amorce sur le premier geste de
 * l'utilisateur, donc il suffit de le monter quelque part pour que le son
 * existe. Aucune autre pièce du jeu n'a à le savoir.
 *
 * Il se pose **en haut à droite**, jamais en bas : le bouton du son de
 * Bataillotom faisait 32 px, posé en bas à droite par-dessus le compteur de
 * latence, et c'est l'un des trois défauts qui ont écrit `docs/mobile.md`.
 */

/** L'amorce n'a lieu qu'une fois par chargement, quel que soit le nombre de montages. */
let amorceFaite = false

export interface BoutonSonProps {
  /** Ajoute le curseur de volume à côté du bouton. Le hub s'en sert, les jeux non. */
  curseur?: boolean
  className?: string
}

export function BoutonSon({ curseur = false, className = '' }: BoutonSonProps) {
  const { volume, coupe, regler, basculer } = useVolume()

  /**
   * L'amorce. Les navigateurs refusent tout son avant un geste : on attend le
   * premier clic, la première touche ou le premier contact.
   *
   * `capture: true` pour passer avant les gestionnaires du jeu, et surtout
   * **rien d'asynchrone** entre l'évènement et `deverrouiller()` : sur iOS
   * Safari une continuation `await` perd le jeton du geste, et le déblocage
   * échoue en silence.
   */
  useEffect(() => {
    if (amorceFaite) return
    const evts = ['pointerdown', 'keydown', 'touchstart'] as const
    const retirer = () => {
      for (const e of evts) window.removeEventListener(e, amorcer, true)
    }
    function amorcer() {
      if (amorceFaite) return
      amorceFaite = true
      retirer()
      deverrouiller()
    }
    for (const e of evts) window.addEventListener(e, amorcer, true)
    return retirer
  }, [])

  const pct = Math.round(volume * 100)

  return (
    <div className={`arcade-son ${coupe ? 'est-coupe' : ''} ${className}`.trim()}>
      <button
        type="button"
        className="arcade-son-bouton"
        aria-pressed={coupe}
        aria-label={coupe ? 'Réactiver le son' : 'Couper le son'}
        title={coupe ? 'Réactiver le son' : 'Couper le son'}
        onClick={() => {
          deverrouiller()
          basculer()
        }}
      >
        {/* Quatre barres d'égaliseur plutôt qu'un haut-parleur : elles disent à
            la fois « son » et « ça joue en ce moment », ce qu'une icône fixe
            ne fait pas. Elles s'immobilisent quand le son est coupé. */}
        <span className="arcade-son-eq" aria-hidden="true">
          <i />
          <i />
          <i />
          <i />
        </span>
      </button>

      {curseur && (
        <input
          type="range"
          className="arcade-son-curseur"
          min={0}
          max={100}
          step={5}
          value={pct}
          style={{ ['--remplissage' as string]: `${pct}%` }}
          aria-label="Volume"
          aria-valuetext={coupe ? 'Coupé' : `${pct} %`}
          onChange={(e) => {
            deverrouiller()
            regler(Number(e.currentTarget.value) / 100)
          }}
        />
      )}
    </div>
  )
}
