import { useCallback, useEffect, useRef, useState } from 'react'

/**
 * Le réglage de son de toute la collection, sous **une seule clé**.
 *
 * Le hub en portait deux — `tombp.arcade.volume` pour la musique,
 * `tombp.arcade.coupure` pour les bruitages — et aucun jeu n'en portait. Deux
 * réglages pour une même question (« est-ce que ça a le droit de faire du
 * bruit ? ») donnent deux boutons qui se contredisent dès qu'on les met côte à
 * côte, ce qui est exactement ce que le cadre commun vient faire.
 *
 * La valeur est un nombre entre 0 et 1, et **zéro veut dire coupé** : pas de
 * booléen à côté, parce qu'un booléen à côté d'un nombre finit toujours par le
 * démentir.
 */

export const CLE_VOLUME = 'tombp.volume'

/**
 * Le domaine de la collection, et la raison d'être du cookie.
 *
 * `localStorage` est cloisonné par **origine**, et la collection en compte
 * douze : `arcade.tombp.fr` et onze sous-domaines. Une seule clé ne suffit donc
 * pas à faire un seul réglage — Rythmotom l'a prouvé en production, en écrivant
 * `0.123` chez lui et en relisant `null` au hub. Couper le son au hub ne coupait
 * rien dans les jeux.
 *
 * Un cookie posé sur `.tombp.fr`, lui, traverse les douze. Il est la source de
 * vérité ; `localStorage` reste le repli, pour `localhost` et pour un
 * navigateur qui refuserait le cookie.
 */
const DOMAINE = 'tombp.fr'

/** Un an : le réglage de son est une préférence, pas une session. */
const UN_AN = 60 * 60 * 24 * 365

/** Le domaine à écrire, ou `null` quand on n'est pas sur `tombp.fr`. */
function domainePartage(): string | null {
  const hote = globalThis.location?.hostname
  if (!hote) return null
  return hote === DOMAINE || hote.endsWith(`.${DOMAINE}`) ? `.${DOMAINE}` : null
}

function lireCookie(): string | null {
  try {
    const brut = globalThis.document?.cookie
    if (!brut) return null
    for (const morceau of brut.split(';')) {
      const egal = morceau.indexOf('=')
      if (egal < 0) continue
      if (morceau.slice(0, egal).trim() !== CLE_VOLUME) continue
      return decodeURIComponent(morceau.slice(egal + 1).trim())
    }
  } catch {
    /* pas de document, ou cookies refusés : le repli fera l'affaire */
  }
  return null
}

function ecrireCookie(valeur: string): void {
  try {
    if (!globalThis.document) return
    const parts = [
      `${CLE_VOLUME}=${encodeURIComponent(valeur)}`,
      'path=/',
      `max-age=${UN_AN}`,
      'SameSite=Lax',
    ]
    const domaine = domainePartage()
    if (domaine) parts.push(`domain=${domaine}`)
    if (globalThis.location?.protocol === 'https:') parts.push('Secure')
    globalThis.document.cookie = parts.join('; ')
  } catch {
    /* idem : on a encore le stockage local */
  }
}

/** Les deux clés du hub d'avant, reprises une fois puis oubliées. */
const ANCIENNE_VOLUME = 'tombp.arcade.volume'
const ANCIENNE_COUPURE = 'tombp.arcade.coupure'

/** Bas à dessein : on vient jouer, pas écouter. */
export const VOLUME_DEFAUT = 0.35

function borner(v: number): number {
  return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : 0
}

/**
 * Lit le réglage.
 *
 * Le stockage est entouré parce qu'il **jette** en navigation privée sur
 * certains navigateurs. Un jeu qui refuserait de s'afficher parce qu'il n'a
 * pas pu lire une préférence de son serait un très mauvais échange.
 */
export function lireVolume(): number {
  // Le cookie d'abord : c'est le seul des deux que les onze jeux partagent
  // avec le hub. Le stockage local ne parle que de l'origine où l'on est.
  const duCookie = lireCookie()
  if (duCookie !== null && duCookie !== '') {
    const v = Number.parseFloat(duCookie)
    if (Number.isFinite(v)) return borner(v)
  }

  try {
    const brut = globalThis.localStorage?.getItem(CLE_VOLUME)
    if (brut !== null && brut !== undefined) {
      const v = Number.parseFloat(brut)
      return Number.isFinite(v) ? borner(v) : VOLUME_DEFAUT
    }

    // La migration n'a lieu qu'une fois : elle écrit la nouvelle clé au
    // passage. La coupure l'emporte sur le volume — quelqu'un qui avait coupé
    // le son ne doit pas retrouver de la musique en revenant.
    if (globalThis.localStorage?.getItem(ANCIENNE_COUPURE) === '1') {
      ecrireVolume(0)
      return 0
    }
    const ancien = globalThis.localStorage?.getItem(ANCIENNE_VOLUME)
    if (ancien !== null && ancien !== undefined) {
      const v = borner(Number.parseFloat(ancien))
      ecrireVolume(v)
      return v
    }
  } catch {
    return VOLUME_DEFAUT
  }
  return VOLUME_DEFAUT
}

export function ecrireVolume(v: number): void {
  const texte = borner(v).toFixed(3)
  // Les deux, toujours : le cookie pour les autres sous-domaines, le stockage
  // pour le cas où le navigateur refuse les cookies.
  ecrireCookie(texte)
  try {
    globalThis.localStorage?.setItem(CLE_VOLUME, texte)
  } catch {
    /* tant pis : le réglage vaudra pour cette visite, et c'est tout ce que
       l'utilisateur a demandé à l'instant. */
  }
}

/**
 * Les abonnés du même onglet.
 *
 * L'évènement `storage` ne se déclenche que dans les *autres* onglets : sans
 * ce registre, un jeu qui affiche deux fois le bouton de son — l'accueil et la
 * pause — les verrait diverger.
 */
const abonnes = new Set<(v: number) => void>()

/** Prévient tout le monde, hooks et bus de son confondus. */
function diffuser(v: number): void {
  for (const a of abonnes) a(v)
}

/**
 * S'abonner au réglage **hors de React**.
 *
 * C'est par là que le bus des bruitages suit le volume : sans abonnement, le
 * gain du bus ne se remettait à jour qu'au prochain `deverrouiller()`, donc on
 * coupait le son et l'on entendait encore le bruitage suivant.
 *
 * Rend la fonction de désabonnement.
 */
export function abonnerVolume(surChangement: (v: number) => void): () => void {
  abonnes.add(surChangement)
  return () => {
    abonnes.delete(surChangement)
  }
}

export interface ReglageSon {
  /** Entre 0 et 1. Zéro veut dire coupé. */
  volume: number
  coupe: boolean
  regler: (v: number) => void
  /** Coupe, ou rétablit le dernier volume non nul. */
  basculer: () => void
}

export function useVolume(): ReglageSon {
  const [volume, setVolume] = useState(lireVolume)
  const dernierNonNul = useRef(volume > 0 ? volume : VOLUME_DEFAUT)

  useEffect(() => {
    const surAbonne = (v: number) => setVolume(v)
    abonnes.add(surAbonne)

    // Un autre onglet a changé le réglage : il faut le rendre au bus de son
    // comme aux autres boutons, pas seulement à celui-ci.
    const surStockage = (e: StorageEvent) => {
      if (e.key === CLE_VOLUME) diffuser(lireVolume())
    }
    window.addEventListener('storage', surStockage)

    return () => {
      abonnes.delete(surAbonne)
      window.removeEventListener('storage', surStockage)
    }
  }, [])

  const regler = useCallback((v: number) => {
    const borne = borner(v)
    if (borne > 0) dernierNonNul.current = borne
    ecrireVolume(borne)
    diffuser(borne)
  }, [])

  const basculer = useCallback(() => {
    regler(lireVolume() > 0 ? 0 : dernierNonNul.current || VOLUME_DEFAUT)
  }, [regler])

  return { volume, coupe: volume <= 0, regler, basculer }
}
