import { fiche } from './fiches.js'

/**
 * Le chemin du retour, un seul pour les onze jeux.
 *
 * Il remplace neuf implémentations d'un même lien : trois symboles, deux
 * libellés, des tailles de vingt-six à quarante-quatre pixels, et onze
 * adresses qui rouvraient toutes le hub sur sa première cartouche après deux
 * secondes de cérémonie.
 *
 * L'adresse porte l'identifiant : `arcade.tombp.fr/#TBP-006` rouvre le rack
 * **sur Yamstom**, sans attract ni boot. C'est ce détail-là qui transforme
 * onze culs-de-sac en une collection.
 *
 * Il se pose **en haut à gauche**, sur l'accueil, la pause et la fin de partie
 * — jamais pendant l'action : une sortie sur le trajet du pouce est un piège
 * (`docs/mobile.md`, « la zone du pouce »).
 */

const HUB = 'https://arcade.tombp.fr'

export interface LienArcadeProps {
  /** L'identifiant du jeu, `TBP-0xx`. Un identifiant inconnu jette au rendu. */
  id: string
  /**
   * Appelé au clic, avant la navigation — pour jouer l'écrasement du tube.
   * Le lien reste un vrai lien : on ne lui retire ni le clic milieu, ni le
   * « ouvrir dans un nouvel onglet ».
   */
  surDepart?: () => void
  className?: string
}

export function LienArcade({ id, surDepart, className = '' }: LienArcadeProps) {
  // Jette si l'identifiant est inconnu : mieux vaut tomber au premier rendu de
  // l'accueil qu'afficher un lien vers une cartouche qui n'existe pas.
  const f = fiche(id)

  return (
    <a
      className={`arcade-lien ${className}`.trim()}
      href={`${HUB}/#${f.id}`}
      onClick={surDepart}
      title={`Retour à l'arcade — ${f.title}`}
    >
      <span className="arcade-lien-losange" aria-hidden="true" />
      <span className="arcade-lien-mot">ARCADE</span>
    </a>
  )
}
