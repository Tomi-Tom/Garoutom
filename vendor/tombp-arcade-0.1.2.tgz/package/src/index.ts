/**
 * `@tombp/arcade` — le cadre commun de la collection.
 *
 * Le contrat tient en une phrase : **le cadre est commun, l'intérieur est
 * libre.** Même gabarit d'accueil, même retour, même son, même transition,
 * même fin, même signature — et chaque jeu garde sa matière, sa palette et son
 * vocabulaire.
 *
 * Aucun composant d'ici n'écrit une couleur en dur : tous passent par les
 * quatre variables déclarées dans `arcade.css`, que le jeu redéfinit.
 */

export { FICHES, GAMES, fiche } from './fiches.js'
export type { Fiche, Game, Statut, GameStatus } from './fiches.js'

export {
  CLE_VOLUME,
  VOLUME_DEFAUT,
  abonnerVolume,
  lireVolume,
  ecrireVolume,
  useVolume,
} from './volume.js'
export type { ReglageSon } from './volume.js'

export { bruitages, deverrouiller, appliquerVolume, contexte, bus } from './bruitages.js'
export type { Verdict } from './bruitages.js'

export { LienArcade } from './LienArcade.js'
export type { LienArcadeProps } from './LienArcade.js'

export { BoutonSon } from './BoutonSon.js'
export type { BoutonSonProps } from './BoutonSon.js'

export { Rideau, DUREE_RIDEAU } from './Rideau.js'
export type { RideauProps } from './Rideau.js'

export { DosDeBoite } from './DosDeBoite.js'
export type { DosDeBoiteProps } from './DosDeBoite.js'

export { EcranFin } from './EcranFin.js'
export type { EcranFinProps, ActionFin } from './EcranFin.js'
