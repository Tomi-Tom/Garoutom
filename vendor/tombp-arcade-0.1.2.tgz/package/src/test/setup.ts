/**
 * La mise en scène commune aux tests de rendu de la collection.
 *
 * Trois doublures, une seule raison pour les trois : jsdom n'implémente ni
 * `matchMedia`, ni `AudioContext`, ni le nettoyage entre deux fichiers. Sans
 * elles, un composant qui respecte le mouvement réduit ou qui joue un bruitage
 * fait tomber le test sur une erreur qui n'a rien à voir avec ce qu'on teste —
 * et l'on passe une heure à chercher un défaut qui n'existe pas.
 */

import '@testing-library/jest-dom/vitest'
import { cleanup } from '@testing-library/react'
import { afterEach, beforeEach, vi } from 'vitest'

if (!window.matchMedia) {
  window.matchMedia = (query: string): MediaQueryList =>
    ({
      matches: false,
      media: query,
      onchange: null,
      addEventListener: () => {},
      removeEventListener: () => {},
      addListener: () => {},
      removeListener: () => {},
      dispatchEvent: () => false,
    }) as MediaQueryList
}

/**
 * Une doublure d'`AudioContext` qui **compte au lieu de sonner**.
 *
 * `noeudsCrees` est public parce que c'est la seule chose qu'un test de son
 * peut honnêtement affirmer : qu'un son a été *demandé*. Ce qu'il donne à
 * entendre se règle à l'oreille, pas dans un `expect`.
 */
export class ContexteAudioFactice {
  static noeudsCrees = 0
  state: AudioContextState = 'running'
  currentTime = 0
  destination = {} as AudioDestinationNode

  private noeud() {
    ContexteAudioFactice.noeudsCrees += 1
    /* `value` retient la dernière valeur demandée, par quelque chemin que ce
       soit. Un `AudioParam` qui oublie ce qu'on lui a demandé rend intestable
       la seule question qu'on ait sur un bus : est-il au volume voulu ? */
    const param = {
      value: 0,
      setValueAtTime: (v: number) => ((param.value = v), param),
      linearRampToValueAtTime: (v: number) => ((param.value = v), param),
      exponentialRampToValueAtTime: (v: number) => ((param.value = v), param),
      setTargetAtTime: (v: number) => ((param.value = v), param),
      cancelScheduledValues: () => param,
    }
    return {
      connect: (suite: unknown) => suite,
      disconnect: () => {},
      start: () => {},
      stop: () => {},
      gain: param,
      frequency: param,
      Q: param,
      type: 'square',
    }
  }

  createOscillator() {
    return this.noeud() as unknown as OscillatorNode
  }
  createGain() {
    return this.noeud() as unknown as GainNode
  }
  createBiquadFilter() {
    return this.noeud() as unknown as BiquadFilterNode
  }
  createBufferSource() {
    return this.noeud() as unknown as AudioBufferSourceNode
  }
  /* Le moteur de musique du hub termine sa chaîne par un analyseur : sans lui,
     le premier geste d'un test faisait tomber le rendu sur une erreur qui n'a
     rien à voir avec ce qu'on teste — le cas exact que ce socle existe pour
     éviter. Il compte comme les autres, et rend un spectre plat. */
  createAnalyser() {
    return {
      ...this.noeud(),
      fftSize: 2048,
      frequencyBinCount: 1024,
      smoothingTimeConstant: 0.6,
      getByteFrequencyData: (tableau: Uint8Array) => tableau.fill(0),
      getByteTimeDomainData: (tableau: Uint8Array) => tableau.fill(128),
    } as unknown as AnalyserNode
  }
  resume() {
    this.state = 'running'
    return Promise.resolve()
  }
  suspend() {
    this.state = 'suspended'
    return Promise.resolve()
  }
  close() {
    this.state = 'closed'
    return Promise.resolve()
  }
}

vi.stubGlobal('AudioContext', ContexteAudioFactice)

beforeEach(() => {
  ContexteAudioFactice.noeudsCrees = 0
  // Un réglage de son laissé par le fichier précédent rendrait le suivant
  // muet, et l'échec parlerait d'autre chose que du défaut réel.
  window.localStorage.clear()
  effacerLesCookies()
})

/**
 * Le réglage de son vit aussi dans un cookie de `.tombp.fr` — c'est ce qui lui
 * permet de traverser les onze sous-domaines. Il faut donc l'effacer entre deux
 * tests, exactement comme le stockage local, et par les deux chemins : le
 * cookie d'hôte et celui du domaine partagé.
 */
function effacerLesCookies(): void {
  try {
    const hote = window.location.hostname
    const parent = hote.split('.').slice(-2).join('.')
    for (const morceau of document.cookie.split(';')) {
      const nom = morceau.split('=')[0]?.trim()
      if (!nom) continue
      document.cookie = `${nom}=; path=/; max-age=0`
      if (parent.includes('.')) document.cookie = `${nom}=; path=/; max-age=0; domain=.${parent}`
    }
  } catch {
    /* pas de document, ou cookies refusés : rien à effacer */
  }
}

afterEach(cleanup)
