import { fileURLToPath } from 'node:url'
import type { UserConfig } from 'vitest/config'

/**
 * La configuration de test de rendu de la maison, en trois lignes chez
 * l'appelant :
 *
 *     import { defineConfig } from 'vitest/config'
 *     import { configVitestRendu } from '@tombp/arcade/test'
 *     export default defineConfig(configVitestRendu())
 *
 * Elle ne fait que trois choses, et c'est exprès : jsdom, la mise en scène
 * commune, et `globals` pour que les tests déjà écrits sans importer
 * `describe` continuent de passer. Tout le reste appartient au jeu.
 */
export function configVitestRendu(sur: UserConfig = {}): UserConfig {
  const notre = fileURLToPath(new URL('./setup.js', import.meta.url))
  const siens = sur.test?.setupFiles
  const listeSiens = siens === undefined ? [] : Array.isArray(siens) ? siens : [siens]

  return {
    ...sur,
    test: {
      environment: 'jsdom',
      globals: true,
      ...sur.test,
      // Après l'étalement, sinon un jeu qui déclare ses propres `setupFiles`
      // effacerait les nôtres sans s'en apercevoir.
      setupFiles: [notre, ...listeSiens],
    },
  }
}
