/**
 * `@tombp/arcade` — le catalogue des onze fiches.
 *
 * Il a déménagé de `hub/src/data/games.ts` pour une raison simple : le pitch
 * vivait au hub et se réécrivait à la main dans chaque jeu, donc le hub pouvait
 * mentir sur ce qu'il annonçait sans que rien ne le dise. Une source unique n'a
 * de sens que si elle est vraiment unique — c'est-à-dire si les onze jeux la
 * lisent, et pas seulement le rack.
 */

export type Statut = 'live' | 'wip' | 'locked'

/** L'ancien nom, gardé pour le hub qui l'emploie déjà. Les jeux écrivent `Statut`. */
export type GameStatus = Statut

export interface Fiche {
  /** Identifiant court, sert aussi de "numéro de disque" */
  id: string
  /** Titre affiché sur la tranche et la jaquette */
  title: string
  /** Sous-titre type édition / baseline */
  subtitle: string
  /** Genre affiché dans le HUD */
  genre: string
  /** Nombre de joueurs */
  players: string
  /** Année de sortie (ou prévue) */
  year: string
  /** Où ça vit. null tant que le jeu n'est pas jouable */
  url: string | null
  /** Repo GitHub, affiché en petit dans le HUD */
  repo: string | null
  status: Statut
  /** Pitch court, façon dos de boîte */
  blurb: string
  /** Barres de stats du HUD, 0-100, façon fiche technique de bagnole */
  stats: { label: string; value: number }[]
  /**
   * Les trois faits qui décident, et que les quatre barres ne disaient pas.
   *
   * VITESSE 062 · TACTIQUE 094 · AMITIÉ 018 : c'est drôle une fois, c'est un
   * décor la deuxième, et cela occupait la moitié de la surface
   * d'information. Ce qu'on cherche vraiment avant de cliquer, c'est combien
   * de temps ça prend, s'il faut quelqu'un d'autre, et si ça se joue au doigt.
   */
  faits: {
    /** « 5 min », « 10 à 20 min ». Mesurée, pas devinée. */
    duree: string
    /** « seul », « à 2, avec des robots », « à 4, tous connectés ». */
    ensemble: string
    commande: 'doigt' | 'clavier' | 'les deux'
  }
  /**
   * Palette du jeu. `base` teinte l'illustration de l'étiquette, `shell` le
   * plastique de la cartouche. Les deux sont dissociés pour pouvoir donner à
   * une cartouche une coque qui contraste avec son artwork ; sans `shell`, la
   * coque reprend `base`.
   */
  palette: { ink: string; base: string; glow: string; accent: string; shell?: string }
  /** Motif de l'étiquette (dessin SVG procédural) */
  art:
    | 'belote'
    | 'gear'
    | 'dice'
    | 'code'
    | 'grid'
    | 'orb'
    | 'bolt'
    | 'bataille'
    | 'yams'
    | 'motus'
    | 'puzzle'
    | 'runner'
    | 'onde'
    | 'gateau'
    | 'none'
}

/**
 * L'ancien nom, gardé parce que le hub l'emploie dans une vingtaine
 * d'endroits et qu'un renommage de plus ne dirait rien de nouveau. Les jeux,
 * eux, écrivent `Fiche`.
 */
export type Game = Fiche

/*
 * Les onze `faits.duree` sont des estimations lues dans le code, pas des
 * mesures — les audits ne donnent que Lutom (≈ 50 min par défaut) et Belotom
 * (92 s de temps machine par donne). Chaque plan de refonte mesure la sienne
 * par simulation et corrige sa ligne ici.
 */
export const FICHES: readonly Fiche[] = [
  {
    id: 'TBP-001',
    title: 'BELOTOM',
    subtitle: 'Belote en ligne · Édition Contrée',
    genre: 'CARTES / TEMPS RÉEL',
    players: '4 JOUEURS · 2 ÉQUIPES',
    year: '2026',
    url: 'https://belotom.tombp.fr',
    repo: 'Tomi-Tom/Belotom',
    status: 'live',
    blurb:
      'Quatre joueurs, deux équipes, un tapis vert. Annonces, atouts, belote et rebelote. La vraie, celle qui finit en engueulade de fin de repas.',
    stats: [
      { label: 'VITESSE', value: 62 },
      { label: 'TACTIQUE', value: 94 },
      { label: 'CHAOS', value: 71 },
      { label: 'AMITIÉ', value: 18 },
    ],
    faits: { duree: '20 à 30 min', ensemble: 'à 4, tous connectés', commande: 'les deux' },
    // Coque bordeaux comme le dos des cartes, étiquette verte comme le tapis :
    // sans ça la cartouche se noyait dans la plaine verte du décor.
    palette: { ink: '#04211a', base: '#0d8f5f', glow: '#8bffc8', accent: '#ffd54a', shell: '#8c2233' },
    art: 'belote',
  },
  {
    id: 'TBP-002',
    title: 'WOLFENSTOM 3D',
    subtitle: 'FPS steampunk · 30 niveaux',
    genre: 'FPS / ROGUELITE',
    players: '1 JOUEUR',
    year: '2026',
    url: 'https://wolfenstom.tombp.fr',
    repo: 'Tomi-Tom/Wolfenstom',
    status: 'live',
    blurb:
      'Trente étages de forteresse mécanique à descendre, trois armes, des automates qui ne voient que devant eux mais que le bruit des tirs réveille. Tout est cuivre, vapeur et engrenages, et rien de tout ça n’est un fichier image.',
    stats: [
      { label: 'VITESSE', value: 88 },
      { label: 'TACTIQUE', value: 66 },
      { label: 'CHAOS', value: 97 },
      { label: 'AMITIÉ', value: 4 },
    ],
    faits: { duree: '10 à 30 min', ensemble: 'seul', commande: 'clavier' },
    palette: { ink: '#1a1109', base: '#9b5e2a', glow: '#e8b84b', accent: '#c8922a' },
    art: 'gear',
  },
  {
    id: 'TBP-003',
    title: 'LUTOM',
    subtitle: 'Petits chevaux · 2 à 4 joueurs',
    genre: 'PLATEAU / DÉS',
    players: '2 À 4 JOUEURS',
    year: '2026',
    url: 'https://ludotom.tombp.fr',
    repo: 'Tomi-Tom/Lutom',
    status: 'live',
    blurb:
      'Sortez vos chevaux sur un 6, faites le tour du plateau, rentrez-les au centre. Trois formules au choix, courte par défaut, et les huit variantes de famille repliées derrière « Régler à la main », parce que chaque maison joue avec ses propres règles et que la dispute commence toujours là.',
    stats: [
      { label: 'VITESSE', value: 54 },
      { label: 'TACTIQUE', value: 47 },
      { label: 'CHAOS', value: 88 },
      { label: 'AMITIÉ', value: 11 },
    ],
    faits: { duree: '15 à 50 min', ensemble: 'à 2 à 4, tous connectés', commande: 'les deux' },
    // Bois verni pour la coque, parchemin et laiton pour l'étiquette : un vrai
    // plateau posé sur une table, à distance du vert et du cuivre des voisines.
    palette: { ink: '#2a1608', base: '#c98b3a', glow: '#ffe0ae', accent: '#e6b93f', shell: '#7d4a24' },
    art: 'dice',
  },
  {
    id: 'TBP-004',
    title: 'MASTOMMIND',
    subtitle: 'Duel de codes · 2 joueurs',
    genre: 'DÉDUCTION / DUEL',
    players: '2 JOUEURS',
    year: '2026',
    url: 'https://mastommind.tombp.fr',
    repo: 'Tomi-Tom/MastomMind',
    status: 'live',
    blurb:
      'Composez un code de couleurs, cassez celui d’en face. Chaque proposition vous dit combien de pions sont bien placés et combien sont de la bonne couleur au mauvais endroit, jamais lesquels. En duel simultané, personne n’attend son tour.',
    stats: [
      { label: 'VITESSE', value: 71 },
      { label: 'TACTIQUE', value: 96 },
      { label: 'CHAOS', value: 22 },
      { label: 'AMITIÉ', value: 63 },
    ],
    faits: { duree: '5 à 10 min', ensemble: 'à 2, tous connectés', commande: 'les deux' },
    // MastomMind — le cyan signature était absent de la cartouche : le jeu est
    // bleu-violet dans le rack et cyan à l'arrivée, donc l'arrivée se lit comme
    // un changement de site. Le projecteur reprend `--neon: #22e2f5`, que
    // personne d'autre ne porte, et la coque prend l'acier de la future
    // identité (« la salle d'écoute, 1974 ») — c'est la part qui ne rebougera
    // pas à la refonte.
    palette: { ink: '#eaf1ff', base: '#1b2740', glow: '#22e2f5', accent: '#ff45a8', shell: '#12151a' },
    art: 'code',
  },
  {
    id: 'TBP-005',
    title: 'BATAILLOTOM',
    subtitle: 'Bataille corse · 2 à 8 joueurs',
    genre: 'CARTES / RÉFLEXE',
    players: '2 À 8 JOUEURS',
    year: '2026',
    url: 'https://bataillotom.tombp.fr',
    repo: 'Tomi-Tom/Bataillotom',
    status: 'live',
    blurb:
      'La bataille corse : on pose une carte, on repère une paire, on tape. Le premier la ramasse, le dernier ramasse tout. Arbitrage au milliseconde par le serveur, huit variantes à cocher, et le doigt qui tremble parce que le voisin a la main plus rapide.',
    stats: [
      { label: 'VITESSE', value: 98 },
      { label: 'TACTIQUE', value: 23 },
      { label: 'CHAOS', value: 84 },
      { label: 'AMITIÉ', value: 9 },
    ],
    faits: { duree: '5 à 15 min', ensemble: 'à 2 à 8, tous connectés', commande: 'doigt' },
    // Bataillotom — la cartouche annonçait marine et rouge urgence ; le jeu est
    // un tapis vert et de l'or, `--color-felt-500: #1d5734` et
    // `--color-gold: #d9a53c`. Aucune couleur commune, donc.
    //
    // Le vrai problème qu'on ne règle pas ici : Belotom et Bataillotom se
    // ressemblent trop *dans la réalité* — deux jeux de cartes sur tapis vert
    // et or — et le rack le réglait en travestissant l'un des deux. On les
    // sépare autrement : Belotom garde son vert vif et sa coque bordeaux,
    // Bataillotom prend le vert sombre et le zinc de sa future identité
    // (« le bar de Corte », #1A1614). Deux verts, deux profondeurs.
    palette: { ink: '#f6f2e8', base: '#1d5734', glow: '#f3ca70', accent: '#d9a53c', shell: '#1a1614' },
    art: 'bataille',
  },
  {
    id: 'TBP-006',
    title: 'YAMSTOM',
    subtitle: 'Le Yams · 2 à 6 joueurs',
    genre: 'DÉS / GRILLE',
    players: '2 À 6 JOUEURS',
    year: '2026',
    url: 'https://yamstom.tombp.fr',
    repo: 'Tomi-Tom/Yamstom',
    status: 'live',
    blurb:
      'Cinq dés, trois lancers, treize cases à remplir. Chaque case vide vous dit ce qu’elle rapporterait avec les dés du moment, mais jamais laquelle choisir. Huit variantes à régler avant de commencer, dont le comptage français du brelan et du carré.',
    stats: [
      { label: 'VITESSE', value: 44 },
      { label: 'TACTIQUE', value: 78 },
      { label: 'CHAOS', value: 66 },
      { label: 'AMITIÉ', value: 81 },
    ],
    faits: { duree: '15 à 25 min', ensemble: 'à 2 à 6, tous connectés', commande: 'les deux' },
    // Papier et feutre : le carnet de score posé sur la table de famille, à
    // l'écart du bois, du cuivre et du néon des voisines.
    palette: { ink: '#2b2418', base: '#c8b28a', glow: '#fff3d8', accent: '#2f6b52', shell: '#8a7048' },
    art: 'yams',
  },
  {
    id: 'TBP-007',
    title: 'MOTUSTOM',
    subtitle: 'Duel de mots · Cinq langues',
    genre: 'LETTRES / DUEL',
    players: '2 JOUEURS',
    year: '2026',
    url: 'https://motustom.tombp.fr',
    repo: 'Tomi-Tom/Motustom',
    status: 'live',
    blurb:
      'Deux joueurs, un même mot, chacun sa grille. Case rouge, la lettre est à sa place ; rond jaune, elle est dans le mot mais ailleurs. On voit l’adversaire avancer sans jamais lire ses lettres, et le premier qui trouve rafle la manche. Français, anglais, espagnol, italien, allemand.',
    stats: [
      { label: 'VITESSE', value: 74 },
      { label: 'TACTIQUE', value: 88 },
      { label: 'CHAOS', value: 31 },
      { label: 'AMITIÉ', value: 55 },
    ],
    faits: { duree: '5 à 10 min', ensemble: 'à 2, tous connectés', commande: 'clavier' },
    // Le bleu de plateau télé et le rouge de la case bien placée : les deux
    // couleurs du jeu, et personne d'autre dans le rack ne porte ce bleu-là.
    palette: { ink: '#eef2ff', base: '#12276b', glow: '#7f9dff', accent: '#f2c230', shell: '#c22b2b' },
    art: 'motus',
  },
  {
    id: 'TBP-008',
    title: 'PUZZLOTOM',
    subtitle: 'Puzzle · Vos images',
    genre: 'PUZZLE / COOPÉRATIF',
    players: '1 À 6 JOUEURS',
    year: '2026',
    url: 'https://puzzlotom.tombp.fr',
    repo: 'Tomi-Tom/Puzzlotom',
    status: 'live',
    blurb:
      'Déposez une image, choisissez le nombre de pièces, et le puzzle se mélange autour du cadre. Les pièces assemblées se déplacent ensemble, et à plusieurs tout le monde manipule les mêmes sur la même table. Votre photo est réduite et débarrassée de ses données de prise de vue avant de partir.',
    stats: [
      { label: 'VITESSE', value: 22 },
      { label: 'TACTIQUE', value: 48 },
      { label: 'CHAOS', value: 14 },
      { label: 'AMITIÉ', value: 96 },
    ],
    faits: { duree: '10 à 40 min', ensemble: 'seul ou à 6, tous connectés', commande: 'les deux' },
    // Bois chaud sous une lampe : la table du soir. Aucune autre cartouche du
    // rack ne porte ce brun, et c'est ce qui la rend reconnaissable en vignette.
    palette: { ink: '#f4ece1', base: '#6b4b2a', glow: '#f2d9a8', accent: '#d98d3a', shell: '#3b3126' },
    art: 'puzzle',
  },
  {
    id: 'TBP-009',
    title: 'RAFALOTOM',
    subtitle: 'Run and gun · Prototype vertical',
    genre: 'ACTION / RUN AND GUN',
    players: '1 JOUEUR',
    year: '2026',
    // En ligne, et toujours en chantier : les deux ne s'excluent pas. L'étiquette
    // dit dans quel état il est, l'adresse permet d'aller y jouer quand même —
    // c'est le seul moyen d'obtenir des retours sur un prototype.
    url: 'https://rafalotom.tombp.fr',
    repo: 'Tomi-Tom/Rafalotom',
    status: 'wip',
    blurb:
      'Un couloir, un personnage, une arme, deux sortes d’ennemis. On court, on saute, on tire dans huit directions. Ce n’est pas encore un jeu : c’est un prototype qui pose une seule question, « est-ce agréable ? ». Pas de boss, pas de véhicule, personne à côté de vous — tout ça est hors périmètre, et l’assumer est la moitié du travail.',
    stats: [
      { label: 'VITESSE', value: 93 },
      { label: 'TACTIQUE', value: 41 },
      { label: 'CHAOS', value: 82 },
      { label: 'AMITIÉ', value: 0 },
    ],
    faits: { duree: '3 à 5 min', ensemble: 'seul', commande: 'clavier' },
    // Rafalotom — violet prune et jade contre un jeu qui est noir et bleu :
    // `--fond: #000`, `--accent: #41a6f6`. Le commentaire d'origine assumait le
    // choix (« personne n'y porte le violet »), c'est-à-dire que la couleur
    // avait été choisie pour la lisibilité du rack et non pour ressembler au
    // jeu. Le prix était une arrivée qui se lit comme un changement de site.
    //
    // La coque prend `#0b0a10`, la nuit de la future identité (« la coulée de
    // nuit ») : aucune autre cartouche n'est presque noire, donc la vignette
    // reste identifiable sans mentir.
    palette: { ink: '#f4f4f4', base: '#101820', glow: '#8fd0ff', accent: '#41a6f6', shell: '#0b0a10' },
    art: 'runner',
  },
  {
    id: 'TBP-010',
    title: 'RYTHMOTOM',
    subtitle: 'Rythme · Vous jouez la mélodie',
    genre: 'MUSIQUE / RYTHME',
    players: '1 JOUEUR',
    year: '2026',
    url: 'https://rythmotom.tombp.fr',
    repo: 'Tomi-Tom/Rythmotom',
    status: 'live',
    blurb:
      'L’accompagnement tourne tout seul ; la mélodie, elle, n’existe que si vous la jouez. Une note ratée ne sonne pas — il reste un trou, à l’endroit exact où vous avez manqué, et l’on n’a plus besoin d’un compteur pour savoir qu’on est mauvais. Quatre morceaux, cent quatre-vingt-treize secondes de musique, et pas un octet d’audio : tout est synthétisé. Trente-sept bandes libres complètent le répertoire.',
    stats: [
      { label: 'VITESSE', value: 88 },
      { label: 'TACTIQUE', value: 34 },
      { label: 'CHAOS', value: 24 },
      { label: 'AMITIÉ', value: 0 },
    ],
    faits: { duree: '3 min', ensemble: 'seul', commande: 'les deux' },
    // Cyan sur noir d'encre : c'est la couleur d'un oscilloscope, et le fond de
    // l'écran du jeu en est un. Le rack n'a aucun cyan franc — les bleus
    // existants tirent tous vers le marine — donc la cartouche se reconnaît en
    // vignette sans qu'on lise son titre.
    palette: { ink: '#03060e', base: '#0e6f96', glow: '#6fd3ff', accent: '#ff5d7e', shell: '#062231' },
    art: 'onde',
  },
  {
    id: 'TBP-011',
    title: 'TARTOTOM',
    subtitle: 'Pâtisserie à la chaîne · 10 services',
    genre: 'ADRESSE / GESTION',
    players: '1 JOUEUR',
    year: '2026',
    // Provisoire : le jeu s'appelle Tartotom, mais le sous-domaine
    // tartotom.tombp.fr n'a pas encore son CNAME chez Scaleway (à créer par
    // Tom, voir GAMES.md). Tant qu'il ne répond pas, la cartouche mène à
    // l'adresse qui sert la v1 — un lien qui marche vaut mieux qu'un nom juste.
    url: 'https://tartopom.tombp.fr',
    repo: 'Tomi-Tom/Tartotom',
    status: 'live',
    blurb:
      'Un client commande un gâteau, sa carte voyage au-dessus du moule, et vous avez la longueur du tapis pour que les deux se ressemblent. Tout tient à une règle : un réglage appartient à la machine, pas au gâteau. Tant qu’il n’y a qu’un moule sur le tapis, cela ne se remarque pas ; dès qu’il y en a trois qui veulent des choses différentes, chaque molette devient un objet qu’on se dispute avec soi-même. Dix services, trois étoiles chacun, et le droit de jeter un gâteau qu’on sait raté plutôt que de fâcher quelqu’un. Le four n’a pas de cadran : la bande dorée est peinte sur le tapis.',
    stats: [
      { label: 'VITESSE', value: 76 },
      { label: 'TACTIQUE', value: 69 },
      { label: 'CHAOS', value: 58 },
      { label: 'AMITIÉ', value: 34 },
    ],
    faits: { duree: '5 min', ensemble: 'seul', commande: 'les deux' },
    // Crème et rose fraise : les dix autres coques sont sombres — bordeaux,
    // cuivre, bois, marine, prune, cyan — et aucune n'est claire. Une boîte de
    // pâtissier posée au milieu du rack se reconnaît donc de loin sans qu'on
    // ait à lire son titre, et la menthe en accent n'existe nulle part ailleurs.
    palette: { ink: '#4a2130', base: '#ef8fb4', glow: '#ffe3ee', accent: '#6ed6b0', shell: '#f2ddc0' },
    art: 'gateau',
  },
  {
    id: 'TBP-012',
    title: 'GAROUTOM',
    subtitle: 'Loup-garou en ligne · 6 à 18 joueurs',
    genre: 'SOCIAL / DÉDUCTION',
    players: '6 À 18 JOUEURS',
    year: '2026',
    // Le CNAME de garoutom.tombp.fr est posé chez Scaleway, mais le jeu
    // n'est pas encore jouable : l'adresse viendra avec le premier client
    // déployé, pas avant. Un bouton « INDISPONIBLE » dit mieux la vérité
    // qu'un lien vers une page vide.
    url: null,
    repo: 'Tomi-Tom/Garoutom',
    status: 'wip',
    blurb:
      "Le village compte ses habitants, la meute compte les siens. Des cartes distribuées en secret, un fil pour se parler le jour, et des nuits où chacun ne voit que ce que son rôle lui permet de savoir : la Voyante sonde, la Sorcière hésite, les loups choisissent. Les skins changent l'habit, jamais les règles — à Thiercelieux on cherche des loups-garous, à Shiganshina des Titans, et la mécanique reste la même.",
    stats: [
      { label: 'VITESSE', value: 14 },
      { label: 'TACTIQUE', value: 88 },
      { label: 'CHAOS', value: 42 },
      { label: 'AMITIÉ', value: 96 },
    ],
    faits: { duree: '20 à 40 min', ensemble: 'à 6, à 18, tous connectés', commande: 'doigt' },
    // La place du village, entre chien et loup : étiquette bleu nocturne,
    // lanterne en halo, sang en accent. La coque prend la lune pâle —
    // aucune autre cartouche du rack n'est gris-bleu clair, et Tartotom est
    // la seule claire : Garoutom se reconnaît en vignette à sa lumière
    // froide, avant même de lire son titre.
    palette: { ink: '#ece3cd', base: '#131726', glow: '#e6a852', accent: '#dd5f52', shell: '#aab4c8' },
    art: 'orb',
  },
]

/** L'ancien nom du tableau, pour les vingt imports du hub. */
export const GAMES = FICHES

/**
 * La fiche d'un jeu, par son identifiant.
 *
 * Elle jette plutôt que de rendre `undefined` : un jeu qui se trompe de
 * numéro doit tomber au premier rendu de son accueil, pas afficher un dos de
 * boîte vide en production.
 */
export function fiche(id: string): Fiche {
  const trouvee = FICHES.find((f) => f.id === id)
  if (!trouvee) {
    throw new Error(
      `@tombp/arcade : aucune fiche pour « ${id} ». Connus : ${FICHES.map((f) => f.id).join(', ')}`,
    )
  }
  return trouvee
}
