import { useEffect, useState, type ReactNode } from 'react'
import { LienArcade } from './LienArcade.js'
import { bruitages, type Verdict as CouleurVerdict } from './bruitages.js'
import { fiche } from './fiches.js'

/**
 * L'écran de fin type, le même dans les onze jeux.
 *
 * Le verdict en un mot, le chiffre en gros, trois lignes de détail, puis
 * **trois boutons dans le même ordre, toujours** : `REJOUER · L'ARCADE ·
 * PARTAGER`. C'est là que la collection se boucle sur elle-même — la fin d'un
 * jeu est la porte d'entrée du suivant.
 *
 * L'ordre n'est pas négociable, et c'est le seul point où le paquet impose
 * quelque chose au jeu : trois boutons qui changent de place d'un jeu à
 * l'autre obligent à lire au lieu de viser.
 *
 * Entre les trois lignes et les actions, le jeu pose **ce qu'il veut** : un
 * classement à six (Yamstom), un podium (Lutom), une frise des ratés
 * (Rythmotom). Le gabarit tient le haut et le bas ; le milieu lui appartient.
 */

export interface ActionFin {
  libelle: string
  surClic: () => void
}

export interface EcranFinProps {
  id: string
  /** Un mot, en capitales : GAGNÉ, PERDU, SERVICE TERMINÉ. */
  verdict: string
  /** Le chiffre qui résume la partie. Déjà mis en forme par le jeu. */
  chiffre: string
  /** Trois lignes de détail. Trois : ni deux, ni sept. */
  lignes: readonly string[]
  /** La couleur du son de fin. Déduite du verdict si elle n'est pas donnée. */
  couleur?: CouleurVerdict
  /** Absent = le jeu ne sait pas rejouer sur place, et le bouton disparaît. */
  surRejouer?: () => void
  /** Les actions propres au jeu, après les trois. */
  actions?: readonly ActionFin[]
  /** Le contenu libre du jeu, sous les trois lignes et avant les actions. */
  children?: ReactNode
  className?: string
}

function deduire(verdict: string): CouleurVerdict {
  const v = verdict.toUpperCase()
  if (v.includes('GAGN') || v.includes('RÉUSSI') || v.includes('BRAVO')) return 'gagne'
  if (v.includes('PERDU') || v.includes('RATÉ') || v.includes('FINI')) return 'perdu'
  return 'neutre'
}

export function EcranFin({
  id,
  verdict,
  chiffre,
  lignes,
  couleur,
  surRejouer,
  actions = [],
  children,
  className = '',
}: EcranFinProps) {
  const f = fiche(id)
  const [partage, setPartage] = useState<'prêt' | 'copié'>('prêt')

  useEffect(() => {
    bruitages.verdict(couleur ?? deduire(verdict))
  }, [verdict, couleur])

  const partager = () => {
    const texte = `${f.title} — ${verdict} · ${chiffre}\n${f.url ?? 'https://arcade.tombp.fr'}`
    // `share` d'abord : sur téléphone c'est la vraie feuille de partage. Le
    // presse-papier est le repli, et il n'échoue jamais silencieusement.
    const partageNatif = (navigator as Navigator & { share?: (d: ShareData) => Promise<void> }).share
    if (partageNatif) {
      void partageNatif({ title: f.title, text: texte }).catch(() => {})
      return
    }
    void navigator.clipboard?.writeText(texte).then(() => {
      setPartage('copié')
      window.setTimeout(() => setPartage('prêt'), 2000)
    })
  }

  return (
    <section className={`arcade-fin ${className}`.trim()}>
      {/* Sans région live, la fin de partie est silencieuse pour un lecteur
          d'écran : on entend le bouton REJOUER, jamais le résultat. */}
      <div role="status" className="arcade-sr arcade-fin-annonce">
        {verdict} · {chiffre}
      </div>

      <h1 className="arcade-fin-verdict">{verdict}</h1>
      <p className="arcade-fin-chiffre">{chiffre}</p>

      <ul className="arcade-fin-lignes">
        {lignes.map((l) => (
          <li key={l}>{l}</li>
        ))}
      </ul>

      {children && <div className="arcade-fin-libre">{children}</div>}

      <nav className="arcade-fin-actions" aria-label="Fin de partie">
        {surRejouer && (
          <button type="button" className="arcade-fin-action est-premiere" onClick={surRejouer}>
            REJOUER
          </button>
        )}
        <LienArcade id={f.id} className="arcade-fin-action" />
        <button type="button" className="arcade-fin-action" onClick={partager}>
          {partage === 'copié' ? 'COPIÉ' : 'PARTAGER'}
        </button>
        {actions.map((a) => (
          <button key={a.libelle} type="button" className="arcade-fin-action" onClick={a.surClic}>
            {a.libelle}
          </button>
        ))}
      </nav>

      <footer className="arcade-fin-pied">
        <span>{f.id}</span>
        <span>
          fait par{' '}
          <a href="https://www.tombp.fr" target="_blank" rel="noopener noreferrer">
            Tomi-Tom
          </a>
        </span>
      </footer>
    </section>
  )
}
